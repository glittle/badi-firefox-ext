﻿/* global getMessage */

var PageCustom = function () {


  var preparePartsList = function () {
    var parts = [];
    var source = shallowCloneOf(_di);
    var partsToSkip = ';bNow;upcomingHtml;frag1SunTimes;frag2SunTimes;';

    for (var partName in source) {
      if (source.hasOwnProperty(partName)) {
        if (partsToSkip.search(';' + partName + ';') !== -1) {
          continue;
        }

        parts.push({
          name: partName,
          type: typeof source[partName]
        });
      };
    }

    parts.sort(function (a, b) {
      return a.name < b.name ? -1 : 1;
    });

    var template = '<div><span class=customPart>#{name}*</span><span class="customPartSample part_{type}" data-part="#{name}*"></span></div>';
    var html = template.filledWithEach(parts).replace(/\#/g, '{').replace(/\*/g, '}');

    $('#partsList').html(html);

    showForCurrentDate();
  };

  function showForCurrentDate() {
    $('#partsList .customPartSample').each(function (i, el) {
      var span = $(el);
      var part = span.data('part');
      span.html(part.filledWith(_di));
    });
  }


  var attachHandlers = function () {
  };

  var recallSettings = function () {
  };

  function startup() {
    preparePartsList();
    recallSettings();
    //updateTotalToExport();
    attachHandlers();
  }

  startup();

  return {
    updateDate: showForCurrentDate
  };
}
